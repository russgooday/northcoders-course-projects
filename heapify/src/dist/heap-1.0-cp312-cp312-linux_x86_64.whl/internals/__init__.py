# pylint: disable=missing-module-docstring
from . _heapify import heapify, heap_replace
